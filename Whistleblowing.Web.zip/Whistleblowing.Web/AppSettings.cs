﻿namespace Whistleblowing.Web
{
    public class AppSettings
    {
        public bool DisabilitaControlloPassword { get; set; }
    }
}
