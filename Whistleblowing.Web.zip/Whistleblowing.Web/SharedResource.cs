﻿namespace Whistleblowing.Web
{
    public class SharedResource
    {
    }
}