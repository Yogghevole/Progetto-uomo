using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Routing;
using R4Mvc;
using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Threading.Tasks;

// Use this file to add custom extensions and helper methods to R4Mvc in your project
internal class R4MvcExtensions
{
}